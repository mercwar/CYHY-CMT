﻿#ifndef AVIS_DEFS_H
#define AVIS_DEFS_H

// Canonical AVIS path length (independent of OS)
#define AVIS_MAX_PATH 512
#define IDT_WIND_REFRESH 2001
#endif
