﻿/*
AVIS:
    artifact: buttons_create.h
    role: ui-button-create-block
    family: cyhy-cmt
    version: 1.0
*/

#ifndef BUTTONS_CREATE_H
#define BUTTONS_CREATE_H

#include <windows.h>

extern HWND hBtnAuto;   // <-- ADD THIS

void BTN_CreateAuto(HWND hWndParent);

#endif
