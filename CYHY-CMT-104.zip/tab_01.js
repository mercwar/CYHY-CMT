/*
AVIS: sentinel001-ai-gf-avis-fvs-cbord-terminal
file=avis-test-log.txt
path=output/
role=terminal
platform=win64
family=cbord
version=1.00
*/

AVIS TEST

test