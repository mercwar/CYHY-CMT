﻿#ifndef COMMON_H
#define COMMON_H

#include <windows.h>
#include "avis_defs.h"

// Keep this ONLY here
typedef struct {
    char path[MAX_PATH];
} CYHY_FILE;

#define MAX_CYHY_FILES 1024

// ... other externs ...

#endif
