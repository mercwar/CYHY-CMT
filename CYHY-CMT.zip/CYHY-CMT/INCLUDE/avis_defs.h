﻿#ifndef AVIS_DEFS_H
#define AVIS_DEFS_H

// Canonical AVIS path length (independent of OS)
#define AVIS_MAX_PATH 512

#endif
