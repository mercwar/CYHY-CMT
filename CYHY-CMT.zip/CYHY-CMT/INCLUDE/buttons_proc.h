﻿/*
AVIS:
    artifact: buttons_proc.h
    role: ui-button-proc-block
    family: cyhy-cmt
    version: 1.0
*/

#ifndef BUTTONS_PROC_H
#define BUTTONS_PROC_H

#include <windows.h>
extern BOOL autoRunning;


void BTN_ProcAuto(HWND hWnd);
#endif
